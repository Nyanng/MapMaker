﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace MapMaker
{
    public partial class MapMaker : Form
    {
        Point MouseVar = new Point();
        Point CurMouseVar = new Point();
        Point FBlock = new Point();
        Point SBlock = new Point();
        bool isDrag = false;
        public int XSize;
        public int YSize;
        public string[,] MapString;
        public string SaveFileString;
        string TileName = "Q";
        MouseButtons MButton;

        public MapMaker()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DoubleBuffered = true;
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            pictureBox1.Width = XSize * 32;
            pictureBox1.Height = YSize * 32;
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            panel1.Location = new Point(81, 27);
            panel1.Width = Width - 81 - 28;
            panel1.Height = Height - 24 - 209;
            panel2.Height = Height - 65;
            listView1.Width = panel1.Width;
            listView1.Location = new Point(panel1.Location.X, panel1.Height + 32);
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            MButton = e.Button;
            MouseVar.X = e.X - e.X % 32;
            MouseVar.Y = e.Y - e.Y % 32;
            CurMouseVar.X = MouseVar.X;
            CurMouseVar.Y = MouseVar.Y;
            isDrag = true;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrag)
            {
                CurMouseVar.X = e.X - e.X % 32;
                CurMouseVar.Y = e.Y - e.Y % 32;
                Refresh();
            }
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            listView1.Items.Clear();
            if (MButton == MouseButtons.Left)
            {
                for (int i = FBlock.Y; i <= SBlock.Y; i++)
                {
                    for (int j = FBlock.X; j <= SBlock.X; j++)
                    {
                        MapString[j, i] = TileName;
                    }
                }
            }
            else if (MButton == MouseButtons.Right)
            {
                for (int i = FBlock.Y; i <= SBlock.Y; i++)
                {
                    for (int j = FBlock.X; j <= SBlock.X; j++)
                    {
                        if (MapString[j, i] != null && MapString[j, i].Contains("_"))
                        {
                            if (MapString[j, i].Split('_')[0] == TileName || MapString[j, i].Split('_')[1] == TileName)
                            {
                                continue;
                            }
                            else
                            {
                                MapString[j, i] += "_" + TileName;
                            }
                        }
                        else if (MapString[j, i] != null && !MapString[j, i].Contains("_"))
                        {
                            if (MapString[j, i] == TileName)
                            {
                                continue;
                            }
                            else
                            {
                                MapString[j, i] += "_" + TileName;
                            }
                        }
                        else if (MapString[j, i] == null)
                        {
                            MapString[j, i] = TileName;
                        }
                    }
                }
            }
            Debug();
            isDrag = false;
            Refresh();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            for (int j = 0; j <= YSize - 1; j++)
            {
                for (int k = 0; k <= XSize - 1; k++)
                {
                    if (MapString[k, j] != null)
                    {
                        var Pen = new SolidBrush(Color.Black);
                        var drawrect = new Rectangle()
                        {
                            X = k * 32,
                            Y = j * 32,
                            Width = 32,
                            Height = 32
                        };

                        string drawText = MapString[k, j].Replace('_', '\n');

                        switch (MapString[k, j])
                        {
                            case "Q":
                                Pen.Color = Color.LightGreen;
                                break;
                            case "W":
                                Pen.Color = Color.SandyBrown;
                                break;
                            case "K":
                                Pen.Color = Color.Red;
                                break;
                            case "Y":
                                Pen.Color = Color.Lime;
                                break;
                            case "U":
                                Pen.Color = Color.Orange;
                                break;
                        }
                        if (MapString[k, j].Contains("P")) Pen.Color = Color.LightCyan;
                        if (MapString[k, j].Contains("D")) Pen.Color = Color.LightPink;
                        if (MapString[k, j].Contains("M")) Pen.Color = Color.Coral;
                        if (MapString[k, j].Contains("A")) Pen.Color = Color.LightSkyBlue;
                        if (MapString[k, j].Contains("Q")) Pen.Color = Color.LightGreen;
                        if (MapString[k, j].Contains("E")) Pen.Color = Color.DarkGreen;
                        if (MapString[k, j].Contains("W")) Pen.Color = Color.SandyBrown;
                        if (MapString[k, j].Contains("R")) Pen.Color = Color.LightGray;
                        if (MapString[k, j].Contains("X")) Pen.Color = Color.MediumPurple;
                        if (MapString[k, j].Contains("T")) Pen.Color = Color.Gray;
                        if (MapString[k, j].Contains("Y")) Pen.Color = Color.Lime;
                        if (MapString[k, j].Contains("U")) Pen.Color = Color.Orange;
                        if (MapString[k, j].Contains("O")) Pen.Color = Color.DarkGray;
                        if (MapString[k, j].Contains("K")) Pen.Color = Color.Red;
                        if (MapString[k, j].Contains("S")) Pen.Color = Color.Yellow;
                        if (MapString[k, j].Contains("L")) Pen.Color = Color.Yellow;

                        e.Graphics.FillRectangle(Pen, drawrect);
                        e.Graphics.DrawString(drawText, new Font("맑은 고딕", 8), new SolidBrush(Color.Black), drawrect);
                    }
                }
            }

            var pen = new Pen(Color.Black, 1);
            var pen2 = new Pen(Color.DarkBlue, 2);
            pen2.Color = MButton == MouseButtons.Left ? Color.DarkBlue : MButton == MouseButtons.Right ? Color.DarkRed : Color.DarkBlue;
            pen.DashStyle = DashStyle.DashDot;
            for (int i = 0; i < XSize; i++)
            {
                e.Graphics.DrawLine(pen, pictureBox1.Width / XSize * i, 0, pictureBox1.Width / XSize * i, pictureBox1.Height);
            }
            for (int j = 0; j < YSize; j++)
            {
                e.Graphics.DrawLine(pen, 0, pictureBox1.Height / YSize * j, pictureBox1.Width, pictureBox1.Height / YSize * j);
            }
            e.Graphics.DrawLine(pen, pictureBox1.Width - 1, 0, pictureBox1.Width - 1, pictureBox1.Height);
            e.Graphics.DrawLine(pen, 0, pictureBox1.Height - 1, pictureBox1.Width, pictureBox1.Height - 1);
            if (isDrag)
            {
                pen2.DashStyle = DashStyle.Solid;
                Rectangle rect = new Rectangle
                {
                    X = MouseVar.X - MouseVar.X % 32,
                    Y = MouseVar.Y - MouseVar.Y % 32
                };

                if (CurMouseVar.X < rect.X + 32)
                {
                    rect.Width = 32;
                }
                else if (CurMouseVar.X >= pictureBox1.Width - 32)
                {
                    rect.Width = pictureBox1.Width - rect.X - CurMouseVar.X % 32;
                }
                else
                {
                    rect.Width = CurMouseVar.X - rect.X - CurMouseVar.X % 32 + 32;
                }

                if (CurMouseVar.Y < rect.Y + 32)
                {
                    rect.Height = 32;
                }
                else if (CurMouseVar.Y >= pictureBox1.Height - 32)
                {
                    rect.Height = pictureBox1.Height - rect.Y - CurMouseVar.Y % 32;
                }
                else
                {
                    rect.Height = CurMouseVar.Y - rect.Y - CurMouseVar.Y % 32 + 32;
                }
                int widthC = (pictureBox1.Width - (pictureBox1.Width - rect.X - CurMouseVar.X % 32)) / 32;
                int heightC = (pictureBox1.Height - (pictureBox1.Height - rect.Y - CurMouseVar.Y % 32)) / 32;
                FBlock.X = widthC;
                FBlock.Y = heightC;
                SBlock.X = (widthC + (rect.Width / 32 - 1));
                SBlock.Y = (heightC + (rect.Height / 32 - 1));
                e.Graphics.DrawRectangle(pen2, rect);
            }
            pen.Dispose();
            pen2.Dispose();
        }

        void Debug()
        {
            string[] errorArr = new string[4];
            bool startLoc = false;
            bool endLoc = false;
            int startCnt = 0;
            int endCnt = 0;
            for (int i = 0; i <= YSize - 1; i++)
            {
                for (int j = 0; j <= XSize - 1; j++)
                {
                    if (MapString[j, i] != null)
                    {
                        string[] AloneTile = { "Q", "W", "E", "R", "T", "A", "X", "K" };
                        string[] AllAloneTile = { "Q", "W", "E", "R", "T", "A", "X", "K", "Y", "U" };
                        string[] AllWithTile = { "M0", "M1", "M2", "M3", "M4", "M5", "M6", "M7", "M8", "M9", "M10", "P1", "D", "P", "O", "S", "L" };
                        string[] WithTile = { "P1", "D", "P", "O", "S", "L" };
                        if (MapString[j, i].Contains("_"))
                        {
                            string[] _SplitText = MapString[j, i].Split('_');
                            startLoc = (_SplitText[1] == "S" || _SplitText[0] == "S") ? true : (startLoc) ? true : false;
                            endLoc = (_SplitText[1] == "L" || _SplitText[0] == "L") ? true : (endLoc) ? true : false;
                            startCnt += (_SplitText[1] == "S" || _SplitText[0] == "S") ? 1 : 0;
                            endCnt += (_SplitText[1] == "L" || _SplitText[0] == "L") ? 1 : 0;
                            foreach (string With in AllWithTile)
                            {
                                foreach (string Alone in AloneTile)
                                {
                                    if (_SplitText[0] == With && _SplitText[1] == Alone ||
                                        _SplitText[1] == With && _SplitText[0] == Alone)
                                    {
                                        goto For_;
                                    }
                                }
                                foreach (string With_ in WithTile)
                                {
                                    if (_SplitText[0] == With && _SplitText[1] == With_ ||
                                        _SplitText[1] == With && _SplitText[0] == With_)
                                    {
                                        goto For_;
                                    }
                                    else if (With == "L" && With_ == "L")
                                    {
                                        errorArr[0] = "Error";
                                        errorArr[1] = (i + 1) + "," + (j + 1);
                                        errorArr[2] = "옳지않은 중복타일 입니다.";
                                        errorArr[3] = MapString[j, i];
                                        listView1.Items.Add(new ListViewItem(errorArr));
                                        goto For_;
                                    }
                                }
                            }
                        }
                        else
                        {
                            startLoc = (MapString[j, i] == "S") ? true : (startLoc) ? true : false;
                            endLoc = (MapString[j, i] == "L") ? true : (endLoc) ? true : false;
                            startCnt += (MapString[j, i] == "S") ? 1 : 0;
                            endCnt += (MapString[j, i] == "L") ? 1 : 0;
                            foreach (string With in AllWithTile)
                            {
                                if (MapString[j, i] == With)
                                {
                                    errorArr[0] = "Error";
                                    errorArr[1] = (i + 1) + "," + (j + 1);
                                    errorArr[2] = "이 타일은 배경타일을 필요로 합니다.";
                                    errorArr[3] = MapString[j, i];
                                    listView1.Items.Add(new ListViewItem(errorArr));
                                    goto For_;
                                }
                            }
                            foreach (string Alone in AllAloneTile)
                            {
                                if (MapString[j, i] == Alone)
                                {
                                    goto For_;
                                }
                                else if (MapString[j, i].Equals(Alone, StringComparison.OrdinalIgnoreCase))
                                {
                                    errorArr[0] = "Error";
                                    errorArr[1] = (i + 1) + "," + (j + 1);
                                    errorArr[2] = "이 타일은 대문자여야합니다.";
                                    errorArr[3] = MapString[j, i];
                                    listView1.Items.Add(new ListViewItem(errorArr));
                                    goto For_;
                                }
                                else if (Alone == "U")
                                {
                                    errorArr[0] = "Error";
                                    errorArr[1] = (i + 1) + "," + (j + 1);
                                    errorArr[2] = "존재하지 않는 타일 입니다.";
                                    errorArr[3] = MapString[j, i];
                                    listView1.Items.Add(new ListViewItem(errorArr));
                                    goto For_;
                                }
                            }
                        }
                        For_:;
                    }
                    else
                    {
                        errorArr[0] = "Error";
                        errorArr[1] = (i + 1) + "," + (j + 1);
                        errorArr[2] = "타일이 비어있습니다.";
                        errorArr[3] = "";
                        listView1.Items.Add(new ListViewItem(errorArr));
                    }
                }
            }
            if (!startLoc)
            {
                errorArr[0] = "Error";
                errorArr[1] = "";
                errorArr[2] = "시작타일이 존재하지 않습니다.";
                errorArr[3] = "";
                listView1.Items.Add(new ListViewItem(errorArr));
            }
            else if (startCnt > 1)
            {
                errorArr[0] = "Error";
                errorArr[1] = "";
                errorArr[2] = "시작타일이 중복됩니다.";
                errorArr[3] = "";
                listView1.Items.Add(new ListViewItem(errorArr));
            }
            if (!endLoc)
            {
                errorArr[0] = "Warning";
                errorArr[1] = "";
                errorArr[2] = "종료타일이 존재하지 않습니다.";
                errorArr[3] = "";
                listView1.Items.Add(new ListViewItem(errorArr));
            }
            else if (endCnt > 1)
            {
                errorArr[0] = "Error";
                errorArr[1] = "";
                errorArr[2] = "종료타일이 중복됩니다.";
                errorArr[3] = "";
                listView1.Items.Add(new ListViewItem(errorArr));
            }
            if (XSize >= 100)
            {
                errorArr[0] = "Warning";
                errorArr[1] = "";
                errorArr[2] = "맵의 Width가 100을 넘어갑니다.";
                errorArr[3] = "";
                listView1.Items.Add(new ListViewItem(errorArr));
            }
            if (YSize >= 100)
            {
                errorArr[0] = "Warning";
                errorArr[1] = "";
                errorArr[2] = "맵의 Height가 100을 넘어갑니다.";
                errorArr[3] = "";
                listView1.Items.Add(new ListViewItem(errorArr));
            }
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            Refresh();
        }

        private void MapMaker_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TileName = "Q";
            label2.Text = "흙";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TileName = "W";
            label2.Text = "풀";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TileName = "E";
            label2.Text = "부쉬";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            TileName = "R";
            label2.Text = "돌";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            TileName = "T";
            label2.Text = "기둥";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            TileName = "D";
            label2.Text = "박스";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            TileName = "A";
            label2.Text = "물";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            TileName = "P";
            label2.Text = "화톳불";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            TileName = "Y";
            label2.Text = "커튼(풀)";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            TileName = "U";
            label2.Text = "커튼(흙)";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            TileName = "K";
            label2.Text = "가시";
        }

        private void button13_Click(object sender, EventArgs e)
        {
            TileName = "O";
            label2.Text = "폭탄";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            TileName = "X";
            label2.Text = "테두리";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            TileName = "S";
            label2.Text = "시작점";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            TileName = "L";
            label2.Text = "끝점";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.Text)
            {
                case "0":
                    TileName = "M0";
                    label2.Text = "몬스터0";
                    break;
                case "1":
                    TileName = "M1";
                    label2.Text = "몬스터1";
                    break;
                case "2":
                    TileName = "M2";
                    label2.Text = "몬스터2";
                    break;
                case "3":
                    TileName = "M3";
                    label2.Text = "몬스터3";
                    break;
                case "4":
                    TileName = "M4";
                    label2.Text = "몬스터4";
                    break;
                case "5":
                    TileName = "M5";
                    label2.Text = "몬스터5";
                    break;
                case "6":
                    TileName = "M6";
                    label2.Text = "몬스터6";
                    break;
                case "7":
                    TileName = "M7";
                    label2.Text = "몬스터7";
                    break;
                case "8":
                    TileName = "M8";
                    label2.Text = "몬스터8";
                    break;
                case "9":
                    TileName = "M9";
                    label2.Text = "몬스터9";
                    break;
                case "10":
                    TileName = "M10";
                    label2.Text = "몬스터10";
                    break;
            }

        }

        private void 저장ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            string fileText = "";
            for (int i = 0; i < YSize; i++)
            {
                for (int j = 0; j < XSize; j++)
                {
                    fileText += MapString[j, i] + ",";
                }
                fileText += Environment.NewLine;
            }
            fileText += "#Width: " + XSize + "," + "#Height: " + YSize;

            if (SaveFileString.Length > 0)
            {
                File.WriteAllText(SaveFileString, fileText);
            }
            else
            {
                var sdlg = new SaveFileDialog();
                sdlg.Filter = "CSV MapFile(*.csv)|*.csv";
                sdlg.ShowDialog();
                File.WriteAllText(sdlg.FileName, fileText);
                SaveFileString = sdlg.FileName;
            }
        }

        private void 다른이름으로저장ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string fileText = "";
            for (int i = 0; i < YSize; i++)
            {
                for (int j = 0; j < XSize; j++)
                {
                    fileText += MapString[j, i] + ",";
                }
                fileText += Environment.NewLine;
            }
            fileText += "#Width: " + XSize + "," + "#Height: " + YSize;
            var sdlg = new SaveFileDialog();
            sdlg.Filter = "CSV MapFile(*.csv)|*.csv";
            sdlg.ShowDialog();
            if (sdlg.FileName.Length > 0)
            {
                File.WriteAllText(sdlg.FileName, fileText);
                SaveFileString = sdlg.FileName;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MapMaker
{
    public partial class Select : Form
    {
        string readText;

        public Select()
        {
            InitializeComponent();
        }

        

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            getweb.Checked = true;
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            getweb.Checked = true;
        }

        private void textBox2_MouseClick(object sender, MouseEventArgs e)
        {
            openfile.Checked = true;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            openfile.Checked = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openfile.Checked = true;
            var opd = new OpenFileDialog();
            opd.Filter = "CSV MapFile(*.csv)|*.csv";
            opd.ShowDialog();
            if(opd.FileName.Length > 0)
            {
                readText = File.ReadAllText(opd.FileName);
                if(readText.Contains("#Width: ") && readText.Contains("#Height: "))
                {
                    textBox2.Text = opd.FileName;
                }
                else
                {
                    MessageBox.Show("올바르지 못한 파일 입니다.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
            }
        }

        private void textBox3_MouseClick(object sender, MouseEventArgs e)
        {
            newfile.Checked = true;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            newfile.Checked = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MapMaker maker_frm = new MapMaker();

            int width_ = 0;
            int height_ = 0;
            if (openfile.Checked)
            {
                readText = File.ReadAllText(textBox2.Text);
                width_ = int.Parse(readText.Split(new string[] { "#Width: " }, StringSplitOptions.None)[1].Split(',')[0]);
                height_ = int.Parse(readText.Split(new string[] { "#Height: " }, StringSplitOptions.None)[1].Split(',')[0]);
                maker_frm.XSize = width_;
                maker_frm.YSize = height_;
                maker_frm.MapString = new string[width_, height_];
                maker_frm.SaveFileString = textBox2.Text;
                string[] SplitNewline = readText.Split('\n');
                for (int i = 0; i < height_; i++)
                {
                    for (int j = 0; j < width_; j++)
                    {
                        string SplitCom = SplitNewline[i].Split(',')[j];
                        if (SplitCom.Contains("//") && SplitCom.Trim().Substring(0, 2) == "//") continue;
                        maker_frm.MapString[j, i] = SplitCom;
                    }
                }
            }
            else if (getweb.Checked)
            {
                var WebC = new WebClient();
                WebC.DownloadFile(textBox1.Text, Application.StartupPath + "/csvFile.csv");
                WebC.Dispose();
                readText = File.ReadAllText(Application.StartupPath + "/csvFile.csv");
                width_ = int.Parse(readText.Split(new string[] { "#Width: " }, StringSplitOptions.None)[1].Split(',')[0]);
                height_ = int.Parse(readText.Split(new string[] { "#Height: " }, StringSplitOptions.None)[1].Split(',')[0]);
                maker_frm.XSize = width_;
                maker_frm.YSize = height_;
                maker_frm.MapString = new string[width_, height_];
                maker_frm.SaveFileString = "";
                string[] SplitNewline = readText.Split('\n');
                for (int i = 0; i < height_; i++)
                {
                    for (int j = 0; j < width_; j++)
                    {
                        string SplitCom = SplitNewline[i].Split(',')[j];
                        if (SplitCom.Contains("//") && SplitCom.Trim().Substring(0, 2) == "//") continue;
                        maker_frm.MapString[j, i] = SplitCom;
                    }
                }
                File.Delete(Application.StartupPath + "/csvFile.csv");
            }
            else if (newfile.Checked)
            {
                width_ = int.Parse(textBox3.Text);
                height_ = int.Parse(textBox4.Text);
                maker_frm.SaveFileString = "";
                maker_frm.XSize = width_;
                maker_frm.YSize = height_;
                maker_frm.MapString = new string[width_, height_];
            }
            maker_frm.Show();
            
            Hide();
        }

        private void Select_Load(object sender, EventArgs e)
        {

        }
    }
}
